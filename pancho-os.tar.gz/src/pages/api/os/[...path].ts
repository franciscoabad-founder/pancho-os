import type { APIRoute } from 'astro';

export const prerender = false;

export const ALL: APIRoute = async ({ request, params, url }) => {
  const targetPath = params.path ?? '';
  const newUrl = new URL(`/api/${targetPath}`, url.origin);
  newUrl.search = url.search;

  const headers = new Headers(request.headers);

  const init: RequestInit = {
    method: request.method,
    headers,
  };

  if (request.method !== 'GET' && request.method !== 'HEAD') {
    init.body = await request.arrayBuffer();
  }

  return fetch(newUrl.toString(), init);
};
